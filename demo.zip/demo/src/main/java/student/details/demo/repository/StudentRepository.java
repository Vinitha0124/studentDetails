package student.details.demo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import student.details.demo.model.Student;

public interface StudentRepository extends MongoRepository<Student, String> {

}
